python cs16831/hw4_part2/scripts/run_hw4_expl.py --env_name PointmassEasy-v0 --use_rnd --unsupervised_exploration --exp_name q6_env1_rnd
python cs16831/hw4_part2/scripts/run_hw4_expl.py --env_name PointmassEasy-v0 --unsupervised_exploration --exp_name q6_env1_random
python cs16831/hw4_part2/scripts/run_hw4_expl.py --env_name PointmassHard-v0 --use_rnd --unsupervised_exploration --exp_name q6_env2_rnd
python cs16831/hw4_part2/scripts/run_hw4_expl.py --env_name PointmassHard-v0 --unsupervised_exploration --exp_name q6_env2_random