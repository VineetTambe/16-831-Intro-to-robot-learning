To get the results ass per the files in `submit/data` run the bash run scripts present in `cs16831/hw4_part1/scripts` and `cs16831/hw4_part2/scripts`.

for problem 1 and problem 2 the commands provided in the homework writeups were used.